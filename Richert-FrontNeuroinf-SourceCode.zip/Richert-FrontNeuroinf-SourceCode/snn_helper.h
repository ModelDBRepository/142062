int cvKeyCheck();

